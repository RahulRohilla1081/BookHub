package com.rahul.glibrary.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.rahul.glibrary.R
import com.rahul.glibrary.activity.DescriptionActivity
import com.rahul.glibrary.module.Book
import com.squareup.picasso.Picasso

class DashboardrecyclerAdapter(val context:Context , val itemList:ArrayList<Book>):RecyclerView.Adapter<DashboardrecyclerAdapter.DashboardViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.recycler_dashboard_single_row,parent,false)

        return DashboardViewHolder(view)

    }


    override fun getItemCount(): Int {
        return itemList.size
    }



    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
        val Book=itemList[position]
        holder.BookName.text=Book.bookName
        holder.AuthorName.text=Book.bookAuthor
        holder.price.text=Book.bookPrice
        holder.rating.text=Book.bookRating
        Picasso.get().load(Book.bookImage).error(R.drawable.default_book_cover).into(holder.image)



        holder.llContent.setOnClickListener{
            val intent=Intent(context,DescriptionActivity::class.java)
            intent.putExtra("book_id",Book.bookId)
            context.startActivity(intent)

        }


    }
class DashboardViewHolder(view:View):RecyclerView.ViewHolder(view) {
    val BookName: TextView = view.findViewById(R.id.BookName)
    val AuthorName: TextView = view.findViewById(R.id.AuhtorName)
    val price: TextView = view.findViewById(R.id.price)
    val rating: TextView = view.findViewById(R.id.rating)
    val image: ImageView = view.findViewById(R.id.imgage)
    val llContent:LinearLayout=view.findViewById(R.id.llContent)

}

}