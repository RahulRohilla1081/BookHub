package com.rahul.glibrary.fragment

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.rahul.glibrary.R
import com.rahul.glibrary.adapter.DashboardrecyclerAdapter
import com.rahul.glibrary.database.BookEntity
import com.rahul.glibrary.module.Book
import com.rahul.glibrary.util.ConnectionManager
import org.json.JSONException
import java.util.*
import kotlin.Comparator
import kotlin.collections.HashMap


class DashBoardFragement : Fragment() {
    lateinit var recyclerDashboard: RecyclerView
    lateinit var layoutManager: RecyclerView.LayoutManager



     lateinit var recyclerAdapeter:DashboardrecyclerAdapter
        lateinit var progresslayout:RelativeLayout
        lateinit var progressBar:ProgressBar
    val  bookInfoList=arrayListOf<Book>()


    var ratingComparator = Comparator<Book>{book1, book2 ->

        if (book1.bookRating.compareTo(book2.bookRating, true) == 0) {
            // sort according to name if rating is same
            book1.bookName.compareTo(book2.bookName, true)
        } else {
            book1.bookRating.compareTo(book2.bookRating, true)
        }
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.fragment_dash_board, container, false)
        setHasOptionsMenu(true)

        recyclerDashboard=view.findViewById(R.id.recyclerDashboard)
//        btnCheckInt=view.findViewById(R.id.btnCheckInt)
        progresslayout=view.findViewById(R.id.progresslayout)
        progressBar=view.findViewById(R.id.progressBar)
        progresslayout.visibility=View.VISIBLE


//        btnCheckInt.setOnClickListener{
//            if(ConnectionManager().checkConnectivity(activity as Context)){
//                //Internet Available
//                val dialog=AlertDialog.Builder(activity as Context)
//                dialog.setTitle("Error")
//                dialog.setMessage("internet not available ")
//                dialog.setPositiveButton("okay"){text,listner->
//                    //handle it
//
//                }
//                dialog.setNegativeButton("Exit"){
//                    text,listner->
//
//                    //do nothing
//                }
//                dialog.create()
//                dialog.show()
//
//            }
//            else{
//                //No Internet Available
//                val dialog=AlertDialog.Builder(activity as Context)
//                dialog.setTitle("Error")
//                dialog.setMessage("Internet Not Available")
//                dialog.setPositiveButton("Okay"){text,listner->
//
//                    //do nothing
//                }
//                dialog.setNegativeButton("Cancel"){
//                    text,listner->
//                    //do nothing
//                }
//                dialog.create()
//                dialog.show()
//            }
//        }
        layoutManager=LinearLayoutManager(activity)





        val queue=Volley.newRequestQueue(activity as Context)
        val url="http://13.235.250.119/v1/book/fetch_books/"

        if(ConnectionManager().checkConnectivity(activity as Context)){

            val jSonObjectRequest=object:JsonObjectRequest(Request.Method.GET, url,null, Response.Listener {
                //here we will handle response
                try {
                    progresslayout.visibility=View.GONE



                    val success = it.getBoolean("success")
                    if (success) {
                        val data = it.getJSONArray("data")

                        for (i in 0 until data.length()) {
                            val bookJSonObject = data.getJSONObject(i)
                            val bookObject = Book(
                                bookJSonObject.getString("book_id"),
                                bookJSonObject.getString("name"),
                                bookJSonObject.getString("author"),
                                bookJSonObject.getString("rating"),
                                bookJSonObject.getString("price"),
                                bookJSonObject.getString("image")
                            )
                            bookInfoList.add(bookObject)
                            recyclerAdapeter =DashboardrecyclerAdapter(activity as Context, bookInfoList)
                            recyclerDashboard.adapter = recyclerAdapeter
                            recyclerDashboard.layoutManager = layoutManager
//                            recyclerDashboard.addItemDecoration(
//                                DividerItemDecoration(
//                                    recyclerDashboard.context,
//                                    (layoutManager as LinearLayoutManager).orientation
//                                )
//                            )
                        }


                    } else {
                        Toast.makeText(activity as Context, "Error occured", Toast.LENGTH_SHORT)
                            .show()
                    }
                }catch (e:JSONException){
                    Toast.makeText(activity as Context, "Unexpected Error Occurred!!", Toast.LENGTH_SHORT).show()
                }


            }
                ,Response.ErrorListener {
                    //here we will handle error
                    if(activity!=null){
                        Toast.makeText(activity as Context, "Please Try Again(Volly error)", Toast.LENGTH_SHORT).show()

                    }

                }
            ){
                override fun getHeaders(): MutableMap<String, String> {
                    val headers=HashMap<String,String>()
                    headers["Content-type"]="application/json"
                    headers["Token"]="032b3f83a8b02c"
                    return headers
                }

            }

            queue.add(jSonObjectRequest)
        }
        else{
            val dialog=AlertDialog.Builder(activity as Context)
            dialog.setTitle("Error")
            dialog.setMessage("Internet Not Available")
            dialog.setPositiveButton("Open Settings"){text,listner->
                val settingsIntent=Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                activity?.finish()

                //do nothing
            }
            dialog.setNegativeButton("Exit"){
                    text,listner->
                ActivityCompat.finishAffinity(activity as Activity)

            }
            dialog.create()
            dialog.show()


        }
                    return view

        }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater?.inflate(R.menu.menu_dashboard, menu)


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id=item?.itemId
        if(id==R.id.action_sort)
        {
            Collections.sort(bookInfoList,ratingComparator)
            bookInfoList.reverse()


        }
        recyclerAdapeter.notifyDataSetChanged()

        return super.onOptionsItemSelected(item)
    }

    }



