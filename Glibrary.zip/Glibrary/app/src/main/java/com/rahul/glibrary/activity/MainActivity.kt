package com.rahul.glibrary.activity

import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.rahul.glibrary.R
import com.rahul.glibrary.fragment.AboutAppFragement
import com.rahul.glibrary.fragment.DashBoardFragement
import com.rahul.glibrary.fragment.FavouriteFragement

class MainActivity : AppCompatActivity()  {

    lateinit var drawerlayout: DrawerLayout
    lateinit var coordinatorLayout: CoordinatorLayout

    lateinit var toolBar: Toolbar
    lateinit var frame: FrameLayout
    lateinit var navView: NavigationView
    var previousMenuItem:MenuItem?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerlayout = findViewById(R.id.drawerlayout)
        coordinatorLayout = findViewById(R.id.coordinatorLayout)
        frame = findViewById(R.id.frame)
        navView = findViewById(R.id.navView)
        toolBar = findViewById(R.id.toolBar)
        setUpToolBar()
        OpenDashboard()
        val toogle = ActionBarDrawerToggle(this@MainActivity,
            drawerlayout,
            R.string.open,
            R.string.close)

        drawerlayout.addDrawerListener(toogle)
        toogle.syncState()

        navView.setNavigationItemSelectedListener {
            if (previousMenuItem != null) {
                previousMenuItem?.isChecked = false
            }
            it.isCheckable = true
            it.isChecked = true
            previousMenuItem = it

            when (it.itemId) {
                R.id.dashboard -> {
                    OpenDashboard()
                    drawerlayout.closeDrawers()
                }




                R.id.favourite -> {
                    supportActionBar?.title = "Favourite"
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame, FavouriteFragement()).commit()
                    drawerlayout.closeDrawers()
                }




                R.id.about_app -> {
                    supportActionBar?.title = "About App"
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame, AboutAppFragement())
                        .commit()
                    drawerlayout.closeDrawers()
                }


            }
            return@setNavigationItemSelectedListener true


        }

    }
    fun setUpToolBar(){
        setSupportActionBar(toolBar)
        supportActionBar?.title="Home"
        supportActionBar?.setHomeButtonEnabled(true)// Sets the home button. Hamburger button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)// Displays the home button.

    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id=item.itemId
        if(id==android.R.id.home)
        {
            drawerlayout.openDrawer(GravityCompat.START)
        }

        return super.onOptionsItemSelected(item)
    }
    fun OpenDashboard(){

        val fragement=DashBoardFragement()
        val transaction=supportFragmentManager.beginTransaction()
            .replace(R.id.frame, DashBoardFragement()).commit()

        supportActionBar?.title="DashBoard"
        navView.setCheckedItem(R.id.dashboard)

    }

    override fun onBackPressed() {
        val frag=supportFragmentManager.findFragmentById(R.id.frame)
        when(frag)
        {
            !is DashBoardFragement ->OpenDashboard()
            else  ->finish()
        }
    }



}